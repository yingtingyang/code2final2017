# emoji_replacer
* A chrome extension for the emoji lovers!!
* It will roughly replace commom emotion words in your browser with emoji!
* Click on the winky face to enable the replacer!
* Have FUN!!
